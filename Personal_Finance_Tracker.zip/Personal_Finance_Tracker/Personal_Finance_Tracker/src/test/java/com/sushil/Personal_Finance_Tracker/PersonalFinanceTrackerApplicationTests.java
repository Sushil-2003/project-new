package com.sushil.Personal_Finance_Tracker;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class PersonalFinanceTrackerApplicationTests {

	@Test
	void contextLoads() {
	}

}
