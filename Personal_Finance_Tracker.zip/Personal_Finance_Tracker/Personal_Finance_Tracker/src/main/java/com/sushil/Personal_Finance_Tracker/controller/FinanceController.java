package com.sushil.Personal_Finance_Tracker.controller;

import com.itextpdf.kernel.pdf.PdfDocument;
import java.io.IOException;
import java.io.StringWriter;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

import org.apache.commons.csv.CSVFormat;
import org.apache.commons.csv.CSVPrinter;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.itextpdf.kernel.pdf.PdfWriter;
import com.itextpdf.layout.Document;
import com.itextpdf.layout.element.Paragraph;
import com.itextpdf.layout.element.Table;
import com.sushil.Personal_Finance_Tracker.model.Budget;
import com.sushil.Personal_Finance_Tracker.model.Category;
import com.sushil.Personal_Finance_Tracker.model.Transaction;
import com.sushil.Personal_Finance_Tracker.model.User;
import com.sushil.Personal_Finance_Tracker.repository.BudgetRepository;
import com.sushil.Personal_Finance_Tracker.repository.CategoryRepository;
import com.sushil.Personal_Finance_Tracker.repository.TransactionRepository;
import com.sushil.Personal_Finance_Tracker.repository.UserRepository;

import jakarta.servlet.http.HttpServletResponse;

@Controller
public class FinanceController {

    @Autowired
    private UserRepository userRepository;

    @Autowired
    private TransactionRepository transactionRepository;

    @Autowired
    private CategoryRepository categoryRepository;

    @Autowired
    private BudgetRepository budgetRepository;

    private User getCurrentUser() {
        String email = SecurityContextHolder.getContext().getAuthentication().getName();
        return userRepository.findByEmail(email).orElseThrow();
    }

    @GetMapping("/login")
    public String login(Model model, @RequestParam(value = "error", required = false) String error) {
        if (error != null) {
            model.addAttribute("error", "Invalid email or password.");
        }
        return "login";
    }

    @GetMapping("/register")
    public String showRegister(Model model) {
        model.addAttribute("user", new User());
        return "register";
    }

    @PostMapping("/register")
    public String register(@ModelAttribute User user, Model model) {
        if (userRepository.findByEmail(user.getEmail()).isPresent()) {
            model.addAttribute("error", "Email already registered.");
            return "register";
        }
        user.setPassword(new org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder().encode(user.getPassword()));
        userRepository.save(user);
        // Initialize default categories for the user
        List<Category> defaultCategories = Arrays.asList("Food", "Housing", "Transportation", "Entertainment", "Salary", "Other")
            .stream().map(name -> {
                Category category = new Category();
                category.setName(name);
                return category;
            }).collect(Collectors.toList());
        categoryRepository.saveAll(defaultCategories);
        model.addAttribute("success", "Registration successful! Please login.");
        return "login";
    }

    @GetMapping("/dashboard")
    public String dashboard(Model model) {
        User user = getCurrentUser();
        List<Transaction> transactions = transactionRepository.findByUser(user);
        Map<String, Double> expenseByCategory = transactions.stream()
            .filter(t -> "expense".equals(t.getType()))
            .collect(Collectors.groupingBy(Transaction::getCategory, Collectors.summingDouble(Transaction::getAmount)));
        double totalIncome = transactions.stream()
            .filter(t -> "income".equals(t.getType()))
            .mapToDouble(Transaction::getAmount).sum();
        double totalExpense = transactions.stream()
            .filter(t -> "expense".equals(t.getType()))
            .mapToDouble(Transaction::getAmount).sum();
        double balance = totalIncome - totalExpense;

        model.addAttribute("expenseCategories", expenseByCategory.keySet());
        model.addAttribute("expenseAmounts", expenseByCategory.values());
        model.addAttribute("totalIncome", totalIncome);
        model.addAttribute("totalExpense", totalExpense);
        model.addAttribute("balance", balance);
        return "dashboard";
    }

    @GetMapping("/transactions")
    public String transactions(Model model, 
                              @RequestParam(defaultValue = "") String filterCategory,
                              @RequestParam(defaultValue = "") String filterType,
                              @RequestParam(defaultValue = "desc") String sortDate) {
        User user = getCurrentUser();
        List<Category> categories = categoryRepository.findByUserIsNullOrUser(user);
        List<Transaction> transactions = transactionRepository.findByUser(user);
        
        // Apply filters
        List<Transaction> filteredTransactions = transactions.stream()
            .filter(t -> filterCategory.isEmpty() || t.getCategory().equals(filterCategory))
            .filter(t -> filterType.isEmpty() || t.getType().equals(filterType))
            .sorted((a, b) -> sortDate.equals("asc") ? a.getDate().compareTo(b.getDate()) : b.getDate().compareTo(a.getDate()))
            .collect(Collectors.toList());

        model.addAttribute("categories", categories);
        model.addAttribute("transactions", filteredTransactions);
        model.addAttribute("transaction", new Transaction());
        model.addAttribute("filterCategory", filterCategory);
        model.addAttribute("filterType", filterType);
        model.addAttribute("sortDate", sortDate);
        return "transactions";
    }

    @PostMapping("/transactions")
    public String addOrUpdateTransaction(@ModelAttribute Transaction transaction) {
        User user = getCurrentUser();
        transaction.setUser(user);
        transactionRepository.save(transaction);
        return "redirect:/transactions";
    }

    @GetMapping("/transactions/edit/{id}")
    public String editTransaction(@PathVariable Long id, Model model) {
        User user = getCurrentUser();
        Transaction transaction = transactionRepository.findById(id)
            .filter(t -> t.getUser().getId().equals(user.getId()))
            .orElseThrow();
        List<Category> categories = categoryRepository.findByUserIsNullOrUser(user);
        model.addAttribute("transaction", transaction);
        model.addAttribute("categories", categories);
        return "transactions";
    }

    @GetMapping("/transactions/delete/{id}")
    public String deleteTransaction(@PathVariable Long id) {
        User user = getCurrentUser();
        transactionRepository.findById(id)
            .filter(t -> t.getUser().getId().equals(user.getId()))
            .ifPresent(transactionRepository::delete);
        return "redirect:/transactions";
    }

    @GetMapping("/transactions/export/csv")
    public void exportToCsv(HttpServletResponse response) throws IOException {
        User user = getCurrentUser();
        List<Transaction> transactions = transactionRepository.findByUser(user);
        response.setContentType("text/csv");
        response.setHeader("Content-Disposition", "attachment; filename=transactions.csv");

        StringWriter writer = new StringWriter();
        CSVPrinter csvPrinter = new CSVPrinter(writer, CSVFormat.DEFAULT.withHeader("Type", "Category", "Date", "Amount"));
        for (Transaction t : transactions) {
            csvPrinter.printRecord(t.getType(), t.getCategory(), t.getDate(), t.getAmount());
        }
        csvPrinter.flush();
        response.getWriter().write(writer.toString());
    }

    @GetMapping("/transactions/export/pdf")
    public void exportToPdf(HttpServletResponse response) throws IOException {
        User user = getCurrentUser();
        List<Transaction> transactions = transactionRepository.findByUser(user);
        response.setContentType("application/pdf");
        response.setHeader("Content-Disposition", "attachment; filename=transactions.pdf");

        PdfWriter writer = new PdfWriter(response.getOutputStream());
        PdfDocument pdf = new PdfDocument(writer);
        Document document = new Document(pdf);
        document.add(new Paragraph("Transaction History: " + user.getName()));
        Table table = new Table(new float[]{1, 2, 2, 1});
        table.addHeaderCell("Type");
        table.addHeaderCell("Category");
        table.addHeaderCell("Date");
        table.addHeaderCell("Amount");
        for (Transaction t : transactions) {
            table.addCell(t.getType());
            table.addCell(t.getCategory());
            table.addCell(t.getDate().toString());
            table.addCell(t.getAmount().toString());
        }
        document.add(table);
        document.close();
    }

    @GetMapping("/reports")
    public String reports(Model model) {
        User user = getCurrentUser();
        List<Transaction> transactions = transactionRepository.findByUser(user);
        Map<String, Double> expenseByCategory = transactions.stream()
            .filter(t -> "expense".equals(t.getType()))
            .collect(Collectors.groupingBy(Transaction::getCategory, Collectors.summingDouble(Transaction::getAmount)));
        double totalIncome = transactions.stream()
            .filter(t -> "income".equals(t.getType()))
            .mapToDouble(Transaction::getAmount).sum();
        double totalExpense = transactions.stream()
            .filter(t -> "expense".equals(t.getType()))
            .mapToDouble(Transaction::getAmount).sum();
        double balance = totalIncome - totalExpense;

        // Monthly summary
        Map<String, Map<String, Double>> monthlySummary = transactions.stream()
            .collect(Collectors.groupingBy(
                t -> t.getDate().format(DateTimeFormatter.ofPattern("yyyy-MM")),
                Collectors.groupingBy(Transaction::getType, Collectors.summingDouble(Transaction::getAmount))
            ));

        model.addAttribute("expenseCategories", expenseByCategory.keySet());
        model.addAttribute("expenseAmounts", expenseByCategory.values());
        model.addAttribute("totalIncome", totalIncome);
        model.addAttribute("totalExpense", totalExpense);
        model.addAttribute("balance", balance);
        model.addAttribute("monthlySummary", monthlySummary);
        return "reports";
    }

    @GetMapping("/budget")
    public String budget(Model model) {
        User user = getCurrentUser();
        List<Category> categories = categoryRepository.findByUserIsNullOrUser(user);
        String currentMonth = LocalDate.now().format(DateTimeFormatter.ofPattern("yyyy-MM"));
        List<Budget> budgets = budgetRepository.findByUserAndMonth(user, currentMonth);
        List<Transaction> transactions = transactionRepository.findByUser(user);
        Map<String, Double> expenses = transactions.stream()
            .filter(t -> t.getDate().format(DateTimeFormatter.ofPattern("yyyy-MM")).equals(currentMonth))
            .filter(t -> "expense".equals(t.getType()))
            .collect(Collectors.groupingBy(Transaction::getCategory, Collectors.summingDouble(Transaction::getAmount)));

        List<String> alerts = new ArrayList<>();
        for (Budget budget : budgets) {
            double spent = expenses.getOrDefault(budget.getCategory(), 0.0);
            if (spent > budget.getAmount()) {
                alerts.add("Budget exceeded for " + budget.getCategory() + ": Spent ₹" + spent + " against ₹" + budget.getAmount());
            }
        }

        model.addAttribute("categories", categories);
        model.addAttribute("budgets", budgets);
        model.addAttribute("budget", new Budget());
        model.addAttribute("alerts", alerts);
        model.addAttribute("currentMonth", currentMonth);
        return "budget";
    }

    @PostMapping("/budget")
    public String addBudget(@ModelAttribute Budget budget, @RequestParam String month) {
        User user = getCurrentUser();
        budget.setUser(user);
        budget.setMonth(month);
        budgetRepository.save(budget);
        return "redirect:/budget";
    }

    @GetMapping("/budget/delete/{id}")
    public String deleteBudget(@PathVariable Long id) {
        User user = getCurrentUser();
        budgetRepository.findById(id)
            .filter(b -> b.getUser().getId().equals(user.getId()))
            .ifPresent(budgetRepository::delete);
        return "redirect:/budget";
    }

    @GetMapping("/settings")
    public String settings(Model model) {
        User user = getCurrentUser();
        List<Category> categories = categoryRepository.findByUserIsNullOrUser(user);
        model.addAttribute("categories", categories);
        model.addAttribute("category", new Category());
        model.addAttribute("darkMode", false); // Managed via cookie or session
        return "settings";
    }

    @PostMapping("/settings/category")
    public String addCategory(@ModelAttribute Category category) {
        User user = getCurrentUser();
        category.setUser(user);
        categoryRepository.save(category);
        return "redirect:/settings";
    }

    @GetMapping("/settings/category/delete/{id}")
    public String deleteCategory(@PathVariable Long id) {
        User user = getCurrentUser();
        categoryRepository.findById(id)
            .filter(c -> c.getUser() != null && c.getUser().getId().equals(user.getId()))
            .ifPresent(categoryRepository::delete);
        return "redirect:/settings";
    }
}