package com.sushil.Personal_Finance_Tracker.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;

import com.sushil.Personal_Finance_Tracker.model.Category;
import com.sushil.Personal_Finance_Tracker.model.User;

public interface CategoryRepository extends JpaRepository<Category, Long> {
    List<Category> findByUserIsNullOrUser(User user);
}