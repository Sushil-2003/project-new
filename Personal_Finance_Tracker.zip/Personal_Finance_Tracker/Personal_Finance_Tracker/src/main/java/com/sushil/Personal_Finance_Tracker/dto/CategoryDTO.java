package com.sushil.Personal_Finance_Tracker.dto;

import lombok.Data;

@Data
public class CategoryDTO {
    private Long id;
    private String name;
}